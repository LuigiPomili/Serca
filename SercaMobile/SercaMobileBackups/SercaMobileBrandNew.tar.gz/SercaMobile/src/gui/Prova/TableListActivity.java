package gui.Prova;

import android.app.ListActivity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

public class TableListActivity extends ListActivity{
	
	private Table[] tableList = new Table[] {new Table("tappof", 3), new Table("gigioftw", 1), new Table("ganesh",2)};
	private String[] nameTable;
	private String[] userConn;
	private SingletonUser user;
	private TableArrayAdapter adapter;
	private Object tlathis = null;
	
	public void onCreate(Bundle icicle) {
		super.onCreate(icicle);
		user = SingletonUser.getInstance();
		user.setTableListhandler(handler);
		tlathis = this;
		// Create an array of Strings, that will be put to our ListActivity
		int numEle = tableList.length;
	    nameTable = new String[numEle];
	    userConn = new String[numEle];
	      for (int i=0; i<numEle; i++){
	    	  nameTable[i]=tableList[i].getNome();
	    	  userConn[i]=Integer.toString(tableList[i].getUsercontable());
	     }
	     adapter = new TableArrayAdapter(this,nameTable,userConn);
	     setListAdapter(adapter);
	}
	
    final Handler handler = new Handler() {
        public void handleMessage(Message msg) {
        		Table[] newtableslist = ((Table[])msg.obj);
        		int numEle;
        		if (msg.obj == null)
        			numEle = 0;
        		else
        			numEle = newtableslist.length;
        		nameTable = new String[numEle];
        		userConn = new String[numEle];
        		for (int i = 0; i < numEle; i++){
        			nameTable[i] = newtableslist[i].getNome();
        			userConn[i] = Integer.toString(newtableslist[i].getUsercontable());
        		}
        		adapter = new TableArrayAdapter((TableListActivity)tlathis, nameTable, userConn);
        		setListAdapter(adapter);
        }
    };

}
