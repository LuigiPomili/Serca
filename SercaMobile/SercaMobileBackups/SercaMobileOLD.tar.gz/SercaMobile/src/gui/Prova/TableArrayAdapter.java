package gui.Prova;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

public class TableArrayAdapter extends ArrayAdapter<String> {
	
	private final Activity context;
	private final String[] tablename;
	private final String[] userconn;

	public TableArrayAdapter(Activity context, String[] tablename, String[] userconn) {
		super(context, R.layout.tablelist, tablename);
		this.context = context;
		this.tablename = tablename;
		this.userconn = userconn;
	}

	static class ViewHolder {
		protected TextView txtNameTable;
		protected TextView txtUserConn;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		View rowView = convertView;
		if (rowView == null) {
			LayoutInflater inflater = context.getLayoutInflater();
			rowView = inflater.inflate(R.layout.tablelist, null, true);
			holder = new ViewHolder();
			holder.txtNameTable = (TextView) rowView.findViewById(R.id.tablename);
			holder.txtUserConn = (TextView) rowView.findViewById(R.id.numconn);
			rowView.setTag(holder);
		} else {
			holder = (ViewHolder) rowView.getTag();
		}

		holder.txtNameTable.setText(tablename[position]);
		if (userconn[position].equals("1")) {
			holder.txtUserConn.setText(userconn[position] + "  user logged on to the table");
		}else{
			holder.txtUserConn.setText(userconn[position] + "  users logged on to the table");
		}
		return rowView;
	}

}
