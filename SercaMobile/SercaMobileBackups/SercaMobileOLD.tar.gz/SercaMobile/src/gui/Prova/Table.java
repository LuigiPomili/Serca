package gui.Prova;

public class Table {
	
	private String nametable;
	private int usercontable;
	
	//public Table list_table[];
	
	
	public Table (String nome, int usercontable) {
		super();
		this.nametable = nome;
		this.usercontable = usercontable;
	}
	
	public String getNome() {
		return nametable;
	}
	public void setNome(String nome) {
		this.nametable = nome;
	}
	public int getUsercontable() {
		return usercontable;
	}
	public void setUsercontable(int usercontable) {
		this.usercontable = usercontable;
	}
}
