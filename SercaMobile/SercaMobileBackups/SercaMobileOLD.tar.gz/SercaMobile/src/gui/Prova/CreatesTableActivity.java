package gui.Prova;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;


public class CreatesTableActivity extends Activity{
	
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.creates_table);
        TextView txtNameTable = (TextView) findViewById(R.id.txtCTNameMyTable);
        String user = SingletonUser.getInstance().getUsername();
        txtNameTable.setText(user);
    }

}
