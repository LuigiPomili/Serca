package gui.Prova;


import android.app.Activity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class ChatActivity extends Activity implements OnClickListener{
	
	private Button butSend;
	private TextView txtChatRead;
	private TextView txtChatWrite;
	
	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.chat);
        butSend = (Button) findViewById(R.id.butSend);
        txtChatWrite = (TextView) findViewById(R.id.txtChatSend);
        txtChatRead = (TextView) findViewById(R.id.txtChatReceve);
        txtChatRead.setMovementMethod(new ScrollingMovementMethod());
        butSend.setOnClickListener(this);
	}

	public void onClick(View v) {
		// TODO Auto-generated method stub
		String txt;
		String user;
		if (!(txtChatWrite.getText().toString().equals(""))) {
			user = SingletonUser.getInstance().getUsername();
			txtChatRead.append (user + " writes: \n");
			txt = txtChatWrite.getText().toString();
			txt = txt + "\n";
			txtChatRead.append(txt);
			txtChatRead.append("\n");
			txtChatWrite.setText("");
		}
	}

}
