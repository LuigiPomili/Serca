package gui.Prova;

import android.app.Activity;
import android.os.Bundle;

public class TableCreatedActivity extends Activity{
	
	public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	    setContentView(R.layout.table_started);
	}

}
