package gui.Prova;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Looper;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class SercaMobileActivity extends Activity implements OnClickListener {
    /** Called when the activity is first created. */
	
	private Button butLogin;
	private Button butRegister;
	private EditText txtUsername;
	private EditText txtPassword;
	private SingletonUser user;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        butLogin = (Button) findViewById(R.id.button1);
        butRegister = (Button) findViewById(R.id.button2);
        txtUsername = (EditText) findViewById(R.id.editText1);
        txtPassword = (EditText) findViewById(R.id.editText2);
        butLogin.setOnClickListener(this);
        butRegister.setOnClickListener(this);
    }


	public void onClick(View v) {
		// TODO Auto-generated method stub
		int IdButton = v.getId();
		
		if (IdButton == butLogin.getId()){
			if ((txtUsername.getText().toString().equals("")) || (txtPassword.getText().toString().equals(""))){
				Context context = getApplicationContext();
				CharSequence text = "You must insert Username and Password. If you are not register, you must register before";
				int duration = Toast.LENGTH_LONG;
				Toast toast = Toast.makeText(context, text, duration);
				toast.show();
			}else{
				//QUA BISOGNA ATTACCARE IL LOGIN
				//setUsername(txtUsername.getText().toString());
				user = SingletonUser.getInstance();
				//al massimo lo prendo dalla risposta che c'ho
				user.setScore(0);
				user.setUsername(txtUsername.getText().toString());
				user.setPassword(txtPassword.getText().toString());
				/*Intent intent = new Intent(this, MyTabActivity.class);
				startActivity(intent);*/
				user.login(this);
			}				
		}
		else if (IdButton == butRegister.getId()){
			//EditText prova = (EditText) findViewById(R.id.editText1);
			//prova.setText("Registra");
			Intent intent = new Intent(this, RegistrationActivity.class);
			startActivity(intent);
		}
	}
	
	public void loginResult(String result){
		if (result.equals("LOGGED_IN")){
			try{
				Intent intent = new Intent(this, MyTabActivity.class);
				startActivity(intent);
			}catch(Exception e){
				System.out.println("Exception");
			}
		}else{
			Context context = getApplicationContext();
			CharSequence text = "Login Failed";
			int duration = Toast.LENGTH_LONG;
			Toast toast = Toast.makeText(context, text, duration);
			toast.show();
		}
	}
	
}