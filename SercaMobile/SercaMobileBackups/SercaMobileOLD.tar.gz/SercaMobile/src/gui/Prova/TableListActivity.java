package gui.Prova;

import android.app.ListActivity;
import android.os.Bundle;

public class TableListActivity extends ListActivity{
	
	private Table[] tableList = new Table[] {new Table("tappof", 3), new Table("gigioftw", 1), new Table("ganesh",2)};
	private String[] nameTable;
	private String[] userConn;
	
	public void onCreate(Bundle icicle) {
		super.onCreate(icicle);
		// Create an array of Strings, that will be put to our ListActivity
		int numEle = tableList.length;
	    nameTable = new String[numEle];
	    userConn = new String[numEle];
	      for (int i=0; i<numEle; i++){
	    	  nameTable[i]=tableList[i].getNome();
	    	  userConn[i]=Integer.toString(tableList[i].getUsercontable());
	      }
	      TableArrayAdapter adapter = new TableArrayAdapter(this,nameTable,userConn);
	      setListAdapter(adapter);
	}

}
