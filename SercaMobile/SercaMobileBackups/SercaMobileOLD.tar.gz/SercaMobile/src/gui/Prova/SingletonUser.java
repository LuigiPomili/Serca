package gui.Prova;

public class SingletonUser {
	private static SingletonUser instance;
	private String username;
	private int score;
	 
    // Private constructor prevents instantiation from other classes
    private SingletonUser() {

    }
 
    public static SingletonUser getInstance() {
    	if (instance == null)
    		instance = new SingletonUser();
        return instance;
    }
    
    public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}	
 
}