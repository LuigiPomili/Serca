package gui.Prova;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

public class UserArrayAdapter extends ArrayAdapter<String>{
	
	private final Activity context;
	private final String[] username;
	private final String[] score;
	
	public UserArrayAdapter(Activity context, String[] username , String[] score) {
		super(context, R.layout.userlist, username);
		this.context = context;
		this.username = username;
		this.score = score;
	}
	
	static class ViewHolder_User {
		protected TextView txtUsername;
		protected TextView txtScore;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder_User holder1;
		View rowView1 = convertView;
		if (rowView1 == null) {
			LayoutInflater inflater = context.getLayoutInflater();
			rowView1 = inflater.inflate(R.layout.userlist, null, true);
			holder1 = new ViewHolder_User();
			holder1.txtUsername = (TextView) rowView1.findViewById(R.id.txtUsername);
			holder1.txtScore = (TextView) rowView1.findViewById(R.id.txtScore);
			rowView1.setTag(holder1);
		} else {
			holder1 = (ViewHolder_User) rowView1.getTag();
		}
		
		holder1.txtUsername.setText(username[position]);
		holder1.txtScore.setText("Score: " + score[position]);
		return rowView1;
	}

}
