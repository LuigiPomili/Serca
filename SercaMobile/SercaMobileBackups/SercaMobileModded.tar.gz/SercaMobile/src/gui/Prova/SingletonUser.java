package gui.Prova;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

import it.unibo.cs.swarch.serca.clientsideconnectionlibrary.SercaConnectionManager.SercaConnectionManager;
import it.unibo.cs.swarch.serca.protocol.jaxb.Login;

public class SingletonUser extends Activity implements PropertyChangeListener {
	private static SingletonUser instance;
	private String username;
	private String password;
	private int score;
	private SercaConnectionManager scm;
	private Context logincontext;
	 
    // Private constructor prevents instantiation from other classes
    private SingletonUser() {

    }
 
    public static SingletonUser getInstance() {
    	if (instance == null)
    		instance = new SingletonUser();
        return instance;
    }
    
    public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

    public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}
	
	public void login(Context logincontext){
		scm = new SercaConnectionManager(username, password);
		Login login = new Login();
        login.setUid(username);
        login.setPwd(password);
        this.logincontext = logincontext;
        
        try {
            scm.requestServerStreamingService("http://localhost:8080/Serca-war/reglog", login,
            		SercaConnectionManager.ConnectionsName.GLOBAL, this);
        } catch (IOException ex) {
            Logger.getLogger(SingletonUser.class.getName()).log(Level.SEVERE, null, ex);
        }
	}

	public void propertyChange(PropertyChangeEvent pce) {
		// TODO Auto-generated method stub
		Object newValue = pce.getNewValue();

        //login reply
        if (newValue instanceof String) {
            if (((String) newValue).equals("LOGGED_IN")) {
        		CharSequence text = "Login Success";
        		int duration = Toast.LENGTH_LONG;
        		Toast toast = Toast.makeText(logincontext, text, duration);
        		toast.show();
				Intent intent = new Intent(logincontext, MyTabActivity.class);
				startActivity(intent);
            } else {
        		CharSequence text = "Login Failed";
        		int duration = Toast.LENGTH_LONG;
        		Toast toast = Toast.makeText(logincontext, text, duration);
        		toast.show();
            }
        } /*else if (newValue instanceof TablesList) {
            TablesList tsl = (TablesList) newValue;

            int tablesListEntries = tablesListModel.getRowCount();

            for (int r = 0; r < tablesListEntries; r++) {
                tablesListModel.removeRow(0);
            }

            java.util.List<TablesList.Table> tables = tsl.getTable();

            for (TablesList.Table t : tables) {
                Object[] row = new Object[3];
                row[0] = t.getId();
                row[1] = t.getMembers();
                row[2] = t.getWatchers();
                tablesListModel.addRow(row);
            }


        } else if (newValue instanceof UsersList) {
            UsersList usl = (UsersList) newValue;

            int usersListEntries = usersListModel.getRowCount();
            for (int r = 0; r < usersListEntries; r++) {
                usersListModel.removeRow(0);
            }

            java.util.List<UsersList.User> users = usl.getUser();
            
            for (UsersList.User u : users) {
                Object[] row = new Object[2];
                row[0] = u.getUid();
                row[1] = u.getScore();
                //TODO: DA ADDARE LO STATUS A CLASSIFICATION
                //row[2] = t.getWatchers();
                usersListModel.addRow(row);
            }



        } else if (newValue instanceof IncomingChatMessage) {
            IncomingChatMessage icm = (IncomingChatMessage) newValue;
            if (icm.getScope().equals("global")) {
                readChat.append(icm.getSender() + ": " + icm.getMessage() + "\n");
                readChat.setCaretPosition(readChat.getText().length());
            }
        } else if (newValue instanceof Problem) {
        }*/
	}
 
}