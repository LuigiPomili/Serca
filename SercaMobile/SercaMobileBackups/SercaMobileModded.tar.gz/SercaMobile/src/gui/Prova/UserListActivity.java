package gui.Prova;

import android.app.ListActivity;
import android.os.Bundle;

public class UserListActivity extends ListActivity{
	
	private User[] userList = new User[] {new User("tappof", 500), new User("gigioftw", 200)};
	private String[] username;
	private String[] score;
	
	public void onCreate(Bundle icicle) {
		super.onCreate(icicle);
		// Create an array of Strings, that will be put to our ListActivity
		int numEle = userList.length;
	    username = new String[numEle];
	    score = new String[numEle];
	      for (int i=0; i<numEle; i++){
	    	  username[i]=userList[i].getUsername();
	    	  score[i]=Integer.toString(userList[i].getScore());
	      }
	      UserArrayAdapter adapter = new UserArrayAdapter(this,username,score);
	      setListAdapter(adapter);
	}

}
