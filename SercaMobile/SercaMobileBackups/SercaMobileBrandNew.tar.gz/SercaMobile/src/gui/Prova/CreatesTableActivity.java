package gui.Prova;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;


public class CreatesTableActivity extends Activity implements OnClickListener{
	
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.creates_table);
        TextView txtNameTable = (TextView) findViewById(R.id.txtCTNameMyTable);
        String user = SingletonUser.getInstance().getUsername();
        txtNameTable.setText(user);
        Button butCreation = (Button)findViewById(R.id.cmdCreaMyTable);
        butCreation.setOnClickListener(this);
    }

	public void onClick(View v) {
		// TODO Auto-generated method stub
		Intent intent = new Intent(this, TabTableActivity.class);
		startActivity(intent);
	}

}
