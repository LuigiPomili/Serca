package gui.Prova;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.ProtocolException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.widget.Toast;

import it.unibo.cs.swarch.serca.clientsideconnectionlibrary.SercaConnectionManager.SercaConnectionManager;
import it.unibo.cs.swarch.protocol.simplexml.classes.IncomingChatMessage;
import it.unibo.cs.swarch.protocol.simplexml.classes.Login;
import it.unibo.cs.swarch.protocol.simplexml.classes.LoginReply;
import it.unibo.cs.swarch.protocol.simplexml.classes.OutgoingChatMessage;
import it.unibo.cs.swarch.protocol.simplexml.classes.TablesList;
import it.unibo.cs.swarch.protocol.simplexml.classes.UsersList;

public class SingletonUser extends Activity implements PropertyChangeListener {
	private static SingletonUser instance;
	private String username;
	private String password;
	private int score;
	private SercaConnectionManager scm;
	private Object loginthis;
	private Object tablelisthandler;
	private Object chathandler;
	private Object userlisthandler;
	 
    // Private constructor prevents instantiation from other classes
    private SingletonUser() {

    }
 
    public static SingletonUser getInstance() {
    	if (instance == null)
    		instance = new SingletonUser();
        return instance;
    }
    
    public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

    public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}
	
	public void login(Object loginthis){
		scm = new SercaConnectionManager(username, password);
		Login login = new Login();
        login.setUid(username);
        login.setPwd(password);
        this.loginthis = loginthis;
        
        try {
            scm.requestServerStreamingService("http://10.0.2.2:8080/Serca-war/reglog", login,
            		SercaConnectionManager.ConnectionsName.GLOBAL, this);
        } catch (IOException ex) {
            Logger.getLogger(SingletonUser.class.getName()).log(Level.SEVERE, null, ex);
        }
	}
	
	public void sendGlobalChatMessage(String message){
		OutgoingChatMessage ocm = new OutgoingChatMessage();
		ocm.setMessage(message);
		ocm.setScope("global");
		try {
			scm.singleRequestReplyService("http://10.0.2.2:8080/Serca-war/chat", ocm, null);
		} catch (ProtocolException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void setTableListhandler(Object tablelisthandler){
		this.tablelisthandler = tablelisthandler;
	}
	
	public void setChathandler(Object chatthis){
		this.chathandler = chatthis;
	}
	
	public void setUserListhandler(Object userlisthandler){
		this.userlisthandler = userlisthandler;
	}

	public void propertyChange(PropertyChangeEvent pce) {
		// TODO Auto-generated method stub
		Object newValue = pce.getNewValue();

		if (newValue != null)
        //login reply
			if (newValue instanceof LoginReply) {
				((SercaMobileActivity)loginthis).loginResult(((LoginReply)newValue).getValue());
			} else if (newValue instanceof TablesList) {
            TablesList tsl = (TablesList) newValue;
            List<it.unibo.cs.swarch.protocol.simplexml.classes.TablesList.Table> tslwrapper = tsl.getTable();
            
            Table[] newtableslist = new Table[tslwrapper.size()];
            try{
            for(int i = 0; i < tslwrapper.size(); i++){
            	newtableslist[i] = new Table(tslwrapper.get(i).getId(),
            			Integer.parseInt(tslwrapper.get(i).getMembers().replace(" player/s allowed", "")));
            }
            }catch(Exception e){
            	System.out.println("Exception");
            }
            if (tablelisthandler != null){
            	Message msg = new Message();
            	if (newtableslist.length == 0)
            		msg.obj = null;
            	else
            		msg.obj = newtableslist;
            	((Handler)tablelisthandler).sendMessage(msg);
            }

        } else if (newValue instanceof UsersList) {
            UsersList usl = (UsersList) newValue;
            List<it.unibo.cs.swarch.protocol.simplexml.classes.UsersList.User> uslwrapper = usl.getUser();

            User[] newuserslist = new User[uslwrapper.size()];
            try{
            for(int i = 0; i < uslwrapper.size(); i++){
            	newuserslist[i] = new User(uslwrapper.get(i).getUid(),
            			uslwrapper.get(i).getScore());
            }
            }catch(Exception e){
            	System.out.println("Exception");
            }
            if (userlisthandler != null){
            	Message msg = new Message();
            	if (newuserslist.length == 0)
            		msg.obj = null;
            	else
            		msg.obj = newuserslist;
            	((Handler)userlisthandler).sendMessage(msg);
            }
        } else if (newValue instanceof IncomingChatMessage) {
            IncomingChatMessage icm = (IncomingChatMessage) newValue;
            if (chathandler != null)
            	if (icm.getScope().equals("global")) {
            		Message msg = new Message();
            		msg.obj = icm.getSender() + ": " + icm.getMessage() + "\n";
            		((Handler)chathandler).sendMessage(msg);
            	}
        } /*else if (newValue instanceof Problem) {
        }*/
	}
 
}